#ifndef CONSTRUCTION_HH
#define CONSTRUCTION_HH

#include "G4SystemOfUnits.hh"
#include "G4VUserDetectorConstruction.hh"
#include "G4VPhysicalVolume.hh"
#include "G4LogicalVolume.hh"
#include "G4Box.hh"
#include "G4Tubs.hh"
#include "G4PVPlacement.hh"
#include "G4NistManager.hh"
#include "G4OpticalSurface.hh"
#include "G4GenericMessenger.hh"
#include "G4LogicalSkinSurface.hh"
#include "G4LogicalBorderSurface.hh"

class MyDetectorConstruction : public G4VUserDetectorConstruction
{

public:
	MyDetectorConstruction();
	~MyDetectorConstruction();
	
	G4LogicalVolume *GetScoringVolume() const { return fScoringVolume; };
	
	virtual G4VPhysicalVolume *Construct();

private:
	virtual void ConstructSDandField();
	
	G4int nCols, nRows;
	
	G4Box *solidWorld, *solidRadiator, *solidDetector, *solidScintillator;

	G4LogicalVolume *logicWorld, *logicRadiator, *logicDetector, *logicScintillator;
	G4VPhysicalVolume *physWorld, *physRadiator, *physDetector, *physScintillator;
	
	G4GenericMessenger *fMessenger;
	
	G4LogicalVolume *fScoringVolume;
	
	G4Material *SiO2, *H2O, *Aerogel, *worldMat, *NaI;
	G4Element *C, *Na, *I;
	
	G4double xWorld, yWorld, zWorld;
	
	void DefineMaterials();
	
	void ConstructCherenkov();
	void ConstructScintillator();
	void ConstructTOF();
	
	G4bool isCherenkov, isScintillator, isTOF;
	
	G4OpticalSurface *mirrorSurface;
};

#endif
